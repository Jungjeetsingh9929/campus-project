# EF Core migrations

This workspace has been updated to use `Database.MigrateAsync()` instead of `EnsureCreatedAsync()`.

Generate and apply the initial production schema from a machine with the .NET SDK installed:

```bash
dotnet tool restore
dotnet ef migrations add InitialProductionSchema --project backend/CampusDigitalTwin.Api --startup-project backend/CampusDigitalTwin.Api
dotnet ef database update --project backend/CampusDigitalTwin.Api --startup-project backend/CampusDigitalTwin.Api
```

The current execution environment does not include the `dotnet` CLI, so generated migration C# files could not be produced or verified here. Do not hand-author production migration files without running `dotnet ef migrations add` and reviewing the generated SQL.
